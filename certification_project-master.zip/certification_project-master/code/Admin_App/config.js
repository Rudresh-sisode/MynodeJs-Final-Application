module.exports = {
    'secret': 'supersecret'
  };