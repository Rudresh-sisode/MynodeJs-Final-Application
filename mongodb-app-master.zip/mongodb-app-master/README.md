# What I Learned

* The basics of using NodeJS, ExpressJS, & EJS
* The basics of MongoDB
* HTTP requests
* Using ZingChart to provide data visualization from a data source
